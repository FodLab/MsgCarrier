//
//  msgCarrierTypes.h
//  msgCarrier
//
//  Created by msgCarrier on 2020/7/2.
//  Copyright © 2020 msgCarrier. All rights reserved.
//

// Event Statistic
typedef const void *msgCarrierTypeEventClientRef;
typedef const void *msgCarrierTypeEventRef;
typedef void (*msgCarrierEventCallback)(msgCarrierTypeEventClientRef *eventClientRef, char *eventName, char *param);
