//
//  MCEventStatistic.h
//  msgCarrier
//
//  Created by zena.tang on 2020/7/2.
//  Copyright © 2020 msgCarrier. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "msgCarrierManager.h"
#import "msgCarrierTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface MCEventStatistic : NSObject

@property(nonatomic, assign) msgCarrierTypeEventClientRef *eventClient;
@property(nonatomic, assign) msgCarrierEventCallback eventCallback;

+ (instancetype)getManager;

+ (void)setEventBlock:(msgCarrierEventBlock)block;

+ (void)OnEvent: (NSString *)eventName param: (NSDictionary * _Nullable)param;

@end

NS_ASSUME_NONNULL_END
