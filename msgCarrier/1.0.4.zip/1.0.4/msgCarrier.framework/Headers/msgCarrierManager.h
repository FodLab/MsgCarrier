//
//  msgCarrierManager.h
//  msgCarrier
//
//  Created by msgCarrier on 2020/6/5.
//  Copyright © 2020 msgCarrier. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^msgCarrierEventBlock)(NSString *eventName, NSDictionary * _Nullable param);

@interface msgCarrierManager : NSObject

@property (nonatomic) BOOL             testMode;
@property (nonatomic, readonly) NSString *appId;

+ (instancetype)getManager;

+ (void) initWithAppId: (NSString *)appId;

+ (int)getSdkVersion;
+ (void)setTestMode:(BOOL)testMode;

+ (void)setEventBlock:(msgCarrierEventBlock)block;

+ (BOOL)msgWarningOn;


+ (void)showNotice:(void(^ __nullable)(void))dismissBlock;


@end

NS_ASSUME_NONNULL_END
