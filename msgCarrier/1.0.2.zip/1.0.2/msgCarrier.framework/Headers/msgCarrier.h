//
//  msgCarrier.h
//  msgCarrier
//
//  Created by zena.tang on 2020/6/16.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for msgCarrier.
FOUNDATION_EXPORT double msgCarrierVersionNumber;

//! Project version string for msgCarrier.
FOUNDATION_EXPORT const unsigned char msgCarrierVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <msgCarrier/PublicHeader.h>

#import <msgCarrier/msgCarrierManager.h>
#import <msgCarrier/MCEventStatistic.h>
#import <msgCarrier/msgCarrierTypes.h>
