//
//  MsgCarrier.h
//  MsgCarrier
//
//  Created by zena.tang on 2020/6/15.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MsgCarrier.
FOUNDATION_EXPORT double MsgCarrierVersionNumber;

//! Project version string for MsgCarrier.
FOUNDATION_EXPORT const unsigned char MsgCarrierVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MsgCarrier/PublicHeader.h>

#import <MsgCarrier/MsgCarrierManager.h>
